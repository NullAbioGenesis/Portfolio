const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const blockWidth = 40;
const blockHeight = 40;
const playerSpeed = 5;
let playerX = canvas.width / 2 - blockWidth / 2;
let playerY = canvas.height / 2 - blockHeight / 2;
let exitX = Math.random() * (canvas.width - blockWidth);
let exitY = Math.random() * (canvas.height - blockHeight);

const numWalls = 10;
let walls = generateRandomWalls(numWalls);

let moveDirection = null;
let isMoving = false;

let score = 0;

function generateRandomWalls(numWalls) {
    const generatedWalls = [];
    const centralWidth = canvas.width / 3;
    const centralHeight = canvas.height / 3;

    const safeZoneX = centralWidth / 2;
    const safeZoneY = centralHeight / 2;

    for (let i = 0; i < numWalls; i++) {
        const wallWidth = Math.random() * (centralWidth / 2) + 50;
        const wallHeight = Math.random() * (centralHeight / 2) + 50;
        const wallX = Math.random() * (canvas.width - wallWidth);
        const wallY = Math.random() * (canvas.height - wallHeight);

        const centralX = (canvas.width - centralWidth) / 2;
        const centralY = (canvas.height - centralHeight) / 2;

        if (
            wallX + wallWidth < centralX - safeZoneX ||
            wallX > centralX + centralWidth + safeZoneX ||
            wallY + wallHeight < centralY - safeZoneY ||
            wallY > centralY + centralHeight + safeZoneY
        ) {
            generatedWalls.push({ x: wallX, y: wallY, width: wallWidth, height: wallHeight });
        } else {
            i--;
        }
    }

    return generatedWalls;
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#222";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "red";
    ctx.fillRect(exitX, exitY, blockWidth, blockHeight);

    ctx.fillStyle = "black";
    walls.forEach(wall => {
        ctx.fillRect(wall.x, wall.y, wall.width, wall.height);
    });

    ctx.fillStyle = "white";
    ctx.fillRect(playerX, playerY, blockWidth, blockHeight);

    ctx.fillStyle = "white";
    ctx.font = "24px Arial";
    ctx.fillText("Score: " + score, 20, 40);

    requestAnimationFrame(draw);
}

function update() {
    if (isMoving) {
        let newX = playerX;
        let newY = playerY;

        if (moveDirection === "left") {
            newX -= playerSpeed;
        } else if (moveDirection === "right") {
            newX += playerSpeed;
        } else if (moveDirection === "up") {
            newY -= playerSpeed;
        } else if (moveDirection === "down") {
            newY += playerSpeed;
        }

        if (!isCollidingWithWalls(newX, newY) && !isCollidingWithBorder(newX, newY)) {
            playerX = newX;
            playerY = newY;
        } else {
            isMoving = false;
        }
    }

    if (
        playerX < exitX + blockWidth &&
        playerX + blockWidth > exitX &&
        playerY < exitY + blockHeight &&
        playerY + blockHeight > exitY
    ) {
        score += 10;
        alert("Congratulations! You reached the exit!\nYour score: " + score);
        resetGame();
    }

    draw();
    requestAnimationFrame(update);
}

function isCollidingWithWalls(x, y) {
    for (const wall of walls) {
        if (
            x < wall.x + wall.width &&
            x + blockWidth > wall.x &&
            y < wall.y + wall.height &&
            y + blockHeight > wall.y
        ) {
            return true;
        }
    }
    return false;
}

function isCollidingWithBorder(x, y) {
    return x < 0 || x + blockWidth > canvas.width || y < 0 || y + blockHeight > canvas.height;
}

function resetGame() {
    playerX = canvas.width / 2 - blockWidth / 2;
    playerY = canvas.height / 2 - blockHeight / 2;
    moveDirection = null;
    isMoving = false;
    generateValidExitPosition();
    walls = generateRandomWalls(numWalls);
    draw();
}

function generateValidExitPosition() {
    do {
        exitX = Math.random() * (canvas.width - blockWidth);
        exitY = Math.random() * (canvas.height - blockHeight);
    } while (isExitCollidingWithWalls());
}

function isExitCollidingWithWalls() {
    for (const wall of walls) {
        if (
            exitX < wall.x + wall.width &&
            exitX + blockWidth > wall.x &&
            exitY < wall.y + wall.height &&
            exitY + blockHeight > wall.y
        ) {
            return true;
        }
    }
    return false;
}

document.addEventListener("keydown", function (event) {
    if (!isMoving) {
        if (event.key === "ArrowLeft") {
            moveDirection = "left";
            isMoving = true;
        } else if (event.key === "ArrowRight") {
            moveDirection = "right";
            isMoving = true;
        } else if (event.key === "ArrowUp") {
            moveDirection = "up";
            isMoving = true;
        } else if (event.key === "ArrowDown") {
            moveDirection = "down";
            isMoving = true;
        }
    }
});

draw();
update();
