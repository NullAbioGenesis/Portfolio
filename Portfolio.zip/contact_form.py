from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/contact', methods=['POST'])
def contact():
    if request.method == 'POST':
        # Handle the contact form submission here
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        # Process the data or send an email
        return "Message sent successfully!"

if __name__ == '__main__':
    app.run(debug=True)
